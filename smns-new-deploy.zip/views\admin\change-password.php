<?php
/**
 * Admin Change Password (for manual change)
 */
require_once '../../config.php';

if (!function_exists('adminChangePasswordResolveReturnTo')) {
    function adminChangePasswordResolveReturnTo($rawValue) {
        $raw = trim((string)$rawValue);
        if ($raw === '') {
            return '';
        }
        $parsed = @parse_url($raw);
        if ($parsed === false) {
            return '';
        }
        if (!empty($parsed['scheme']) || !empty($parsed['host'])) {
            return '';
        }
        $path = (string)($parsed['path'] ?? '');
        if ($path === '' || strpos($path, '/views/admin/') !== 0) {
            return '';
        }
        $normalized = $path;
        if (!empty($parsed['query'])) {
            $normalized .= '?' . $parsed['query'];
        }
        if (!empty($parsed['fragment'])) {
            $normalized .= '#' . $parsed['fragment'];
        }
        return $normalized;
    }
}



$session = new Session('admin');
$auth = new Auth('admin');

// Ensure admin is logged in
if (!$auth->isLoggedIn() || !$auth->hasRole('admin')) {
    $redirectUrl = 'login.php?error=unauthorized';
    if (!empty($_SERVER['REQUEST_URI'])) {
        $requestPath = (string)parse_url((string)$_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $requestQuery = (string)parse_url((string)$_SERVER['REQUEST_URI'], PHP_URL_QUERY);
        $relativePath = str_replace(BASE_URL, '', $requestPath);
        if ($relativePath !== '' && strpos($relativePath, '/views/admin/') === 0) {
            $returnTo = $relativePath;
            if ($requestQuery !== '') {
                $returnTo .= '?' . $requestQuery;
            }
            $redirectUrl .= '&return_to=' . urlencode($returnTo);
        }
    }
    header('Location: ' . $redirectUrl);
    exit;
}

$currentUser = $auth->getCurrentUser();
$userId = $currentUser['id'] ?? null;
$returnTo = adminChangePasswordResolveReturnTo($_GET['return_to'] ?? $_POST['return_to'] ?? '');
$postChangeTarget = $returnTo !== '' ? (BASE_URL . $returnTo) : 'dashboard.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Security::verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = 'All fields are required.';
        } elseif ($new_password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } else {
            $policyErrors = [];
            if (!Security::validatePasswordPolicy($new_password, $policyErrors)) {
                $error = implode(' ', $policyErrors);
            }
        }
        if (empty($error)) {
            $result = $auth->changeCurrentUserPassword($current_password, $new_password, $confirm_password);
            if (!empty($result['success'])) {
                $success = (string)($result['message'] ?? 'Password changed successfully.');
                header('Location: ' . $postChangeTarget);
                exit;
            }
            $error = (string)($result['message'] ?? 'Failed to change password.');
        } else {
            // keep validation error
        }
    }
}

// If this was an AJAX request, return JSON instead of rendering the full page
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => !empty($success),
        'message' => $success,
        'error' => $error
    ]);
    exit;
}

$pageTitle = 'Change Password - ' . APP_NAME;
include '../../includes/header.php';
?>
<?php include '../../includes/admin/sidebar.php'; ?>
<div class="main-content">
    <div class="topbar"><div class="topbar-left"><h4>Change Password</h4></div></div>
    <div class="content-area">
        <?php if ($success): ?><div class="alert alert-success"><?php echo e($success); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo e($error); ?></div><?php endif; ?>
        <div class="card"><div class="card-body">
            <form method="POST">
                <?php echo csrfField(); ?>
                <input type="hidden" name="return_to" value="<?php echo e($returnTo); ?>">
                <div class="form-group"><label>Current Password</label><input type="password" name="current_password" class="form-control" required></div>
                <div class="form-group"><label>New Password</label><input type="password" name="new_password" class="form-control" required></div>
                <div class="form-group"><label>Confirm New Password</label><input type="password" name="confirm_password" class="form-control" required></div>
                <div class="text-right"><button type="submit" class="btn btn-primary">Change Password</button></div>
            </form>
        </div></div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>

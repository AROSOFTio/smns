<?php
/**
 * Students List - Admin (Fixed Version)
 */
require_once '../../../config.php';

// Simple session handling


// Initialize with admin module context
$session = new Session('admin');
$auth = new Auth('admin');

// Verify admin access
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true || $_SESSION['admin_role'] !== 'admin') {
    header('Location: ' . BASE_URL . '/views/auth/login.php?error=unauthorized&role=admin');
    exit;
}

$currentUser = $auth->getCurrentUser();

// Get filter parameters
$normalizeFilterValue = static function ($value): string {
    $value = trim((string)$value);
    return preg_replace('/\s+/', ' ', $value) ?? '';
};
$search = $normalizeFilterValue($_GET['search'] ?? '');
$program = $normalizeFilterValue($_GET['program'] ?? '');
$status = $normalizeFilterValue($_GET['status'] ?? '');
$level = $normalizeFilterValue($_GET['level'] ?? '');
$allowedPageSizes = [25, 50, 100];
$rowsPerPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 25;
if (!in_array($rowsPerPage, $allowedPageSizes, true)) {
    $rowsPerPage = 25;
}
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($currentPage <= 0) {
    $currentPage = 1;
}

$buildListUrl = static function (int $page, int $perPage, string $search, string $program, string $status, string $level): string {
    $query = [];
    if ($search !== '') {
        $query['search'] = $search;
    }
    if ($program !== '') {
        $query['program'] = $program;
    }
    if ($status !== '') {
        $query['status'] = $status;
    }
    if ($level !== '') {
        $query['level'] = $level;
    }
    if ($page > 1) {
        $query['page'] = $page;
    }
    if ($perPage > 0) {
        $query['per_page'] = $perPage;
    }
    return 'list.php' . (!empty($query) ? ('?' . http_build_query($query)) : '');
};
$currentListUrl = $buildListUrl($currentPage, $rowsPerPage, $search, $program, $status, $level);

// Build query
$db = new Database();
$conn = $db->getConnection();

$fromWhereSql = " FROM students s
        INNER JOIN programs p ON s.program_id = p.id
        INNER JOIN users u ON s.user_id = u.id
        WHERE 1=1";

$params = [];

if ($search) {
    $searchTokens = preg_split('/\s+/', $search) ?: [];
    $tokenIndex = 0;
    foreach ($searchTokens as $token) {
        $token = trim((string)$token);
        if ($token === '') {
            continue;
        }
        $studentIdKey = 'search_student_id_' . $tokenIndex;
        $admissionKey = 'search_admission_' . $tokenIndex;
        $firstNameKey = 'search_first_name_' . $tokenIndex;
        $otherNameKey = 'search_other_name_' . $tokenIndex;
        $middleNameKey = 'search_middle_name_' . $tokenIndex;
        $lastNameKey = 'search_last_name_' . $tokenIndex;
        $emailKey = 'search_email_' . $tokenIndex;
        $fullNameKey = 'search_full_name_' . $tokenIndex;
        $reverseNameKey = 'search_reverse_name_' . $tokenIndex;
        $fromWhereSql .= " AND (
            s.student_id LIKE :{$studentIdKey}
            OR COALESCE(s.admission_number, '') LIKE :{$admissionKey}
            OR s.first_name LIKE :{$firstNameKey}
            OR COALESCE(s.other_name, '') LIKE :{$otherNameKey}
            OR COALESCE(s.middle_name, '') LIKE :{$middleNameKey}
            OR s.last_name LIKE :{$lastNameKey}
            OR s.email LIKE :{$emailKey}
            OR CONCAT_WS(' ', s.first_name, s.other_name, s.middle_name, s.last_name) LIKE :{$fullNameKey}
            OR CONCAT_WS(' ', s.last_name, s.first_name, s.other_name, s.middle_name) LIKE :{$reverseNameKey}
        )";
        $tokenLike = '%' . $token . '%';
        $params[$studentIdKey] = $tokenLike;
        $params[$admissionKey] = $tokenLike;
        $params[$firstNameKey] = $tokenLike;
        $params[$otherNameKey] = $tokenLike;
        $params[$middleNameKey] = $tokenLike;
        $params[$lastNameKey] = $tokenLike;
        $params[$emailKey] = $tokenLike;
        $params[$fullNameKey] = $tokenLike;
        $params[$reverseNameKey] = $tokenLike;
        $tokenIndex++;
    }
}

if ($program) {
    $fromWhereSql .= " AND s.program_id = :program";
    $params['program'] = $program;
}

if ($status) {
    $statusKey = strtolower($status);
    if ($statusKey === 'graduated') {
        $fromWhereSql .= " AND (
            LOWER(COALESCE(s.status, '')) = :status
            OR LOWER(COALESCE(s.academic_status, '')) = :status_academic
            OR s.graduation_date IS NOT NULL
            OR COALESCE(s.graduation_award_title, '') <> ''
        )";
        $params['status'] = $statusKey;
        $params['status_academic'] = 'graduated';
    } else {
        $fromWhereSql .= " AND LOWER(COALESCE(s.status, '')) = :status";
        $params['status'] = $statusKey;
    }
}

if ($level) {
    $fromWhereSql .= " AND s.level_year = :level";
    $params['level'] = $level;
}

if (isset($_GET['student_lookup']) && $_GET['student_lookup'] === '1') {
    header('Content-Type: application/json');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

    $lookupTerm = $normalizeFilterValue($_GET['term'] ?? '');
    if ($lookupTerm === '') {
        echo json_encode(['success' => true, 'matches' => []]);
        exit;
    }

    $lookupSql = "SELECT s.id, s.student_id, s.admission_number, s.first_name, s.last_name
        " . $fromWhereSql . "
        ORDER BY
            CASE
                WHEN CONCAT_WS(' ', s.first_name, s.last_name) LIKE :lookup_prefix_name THEN 0
                WHEN s.student_id LIKE :lookup_prefix_student THEN 1
                WHEN COALESCE(s.admission_number, '') LIKE :lookup_prefix_admission THEN 2
                ELSE 3
            END,
            s.first_name ASC,
            s.last_name ASC
        LIMIT 6";
    $lookupStmt = $conn->prepare($lookupSql);
    foreach ($params as $k => $v) {
        $lookupStmt->bindValue(':' . $k, $v);
    }
    $lookupStmt->bindValue(':lookup_prefix_name', $lookupTerm . '%');
    $lookupStmt->bindValue(':lookup_prefix_student', $lookupTerm . '%');
    $lookupStmt->bindValue(':lookup_prefix_admission', $lookupTerm . '%');
    $lookupStmt->execute();
    $lookupRows = $lookupStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $matches = [];
    foreach ($lookupRows as $row) {
        $matches[] = [
            'id' => (int)($row['id'] ?? 0),
            'name' => trim((string)($row['first_name'] ?? '') . ' ' . (string)($row['last_name'] ?? '')),
            'student_id' => (string)resolveDisplayedStudentRegistrationNumberFromRow($conn, $row),
            'admission_number' => (string)($row['admission_number'] ?? ''),
        ];
    }

    echo json_encode(['success' => true, 'matches' => $matches]);
    exit;
}

$totalStudents = 0;
try {
    $countStmt = $conn->prepare("SELECT COUNT(*)" . $fromWhereSql);
    foreach ($params as $k => $v) {
        $countStmt->bindValue(':' . $k, $v);
    }
    $countStmt->execute();
    $totalStudents = (int)$countStmt->fetchColumn();
} catch (Exception $e) {
    $totalStudents = 0;
}
$totalPages = max(1, (int)ceil($totalStudents / max($rowsPerPage, 1)));
if ($currentPage > $totalPages) {
    $currentPage = $totalPages;
}
$offset = ($currentPage - 1) * $rowsPerPage;

$students = [];
try {
    $sql = "SELECT s.*, p.program_code, p.program_name, u.status as user_status"
        . $fromWhereSql
        . " ORDER BY s.created_at DESC LIMIT :limit_rows OFFSET :offset_rows";
    $stmt = $conn->prepare($sql);
    foreach ($params as $k => $v) {
        $stmt->bindValue(':' . $k, $v);
    }
    $stmt->bindValue(':limit_rows', $rowsPerPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset_rows', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $students = $stmt->fetchAll();
} catch (Exception $e) {
    $students = [];
}
$searchFilterHint = null;
if ($search !== '' && $totalStudents === 0 && $status !== '') {
    try {
        $hintSql = "SELECT s.student_id, s.first_name, s.last_name, s.status, s.academic_status
            FROM students s
            INNER JOIN programs p ON s.program_id = p.id
            INNER JOIN users u ON s.user_id = u.id
            WHERE 1=1";
        $hintParams = [];
        $searchTokens = preg_split('/\s+/', $search) ?: [];
        $tokenIndex = 0;
        foreach ($searchTokens as $token) {
            $token = trim((string)$token);
            if ($token === '') {
                continue;
            }
            $studentIdKey = 'hint_search_student_id_' . $tokenIndex;
            $admissionKey = 'hint_search_admission_' . $tokenIndex;
            $firstNameKey = 'hint_search_first_name_' . $tokenIndex;
            $otherNameKey = 'hint_search_other_name_' . $tokenIndex;
            $middleNameKey = 'hint_search_middle_name_' . $tokenIndex;
            $lastNameKey = 'hint_search_last_name_' . $tokenIndex;
            $emailKey = 'hint_search_email_' . $tokenIndex;
            $fullNameKey = 'hint_search_full_name_' . $tokenIndex;
            $reverseNameKey = 'hint_search_reverse_name_' . $tokenIndex;
            $hintSql .= " AND (
                s.student_id LIKE :{$studentIdKey}
                OR COALESCE(s.admission_number, '') LIKE :{$admissionKey}
                OR s.first_name LIKE :{$firstNameKey}
                OR COALESCE(s.other_name, '') LIKE :{$otherNameKey}
                OR COALESCE(s.middle_name, '') LIKE :{$middleNameKey}
                OR s.last_name LIKE :{$lastNameKey}
                OR s.email LIKE :{$emailKey}
                OR CONCAT_WS(' ', s.first_name, s.other_name, s.middle_name, s.last_name) LIKE :{$fullNameKey}
                OR CONCAT_WS(' ', s.last_name, s.first_name, s.other_name, s.middle_name) LIKE :{$reverseNameKey}
            )";
            $tokenLike = '%' . $token . '%';
            $hintParams[$studentIdKey] = $tokenLike;
            $hintParams[$admissionKey] = $tokenLike;
            $hintParams[$firstNameKey] = $tokenLike;
            $hintParams[$otherNameKey] = $tokenLike;
            $hintParams[$middleNameKey] = $tokenLike;
            $hintParams[$lastNameKey] = $tokenLike;
            $hintParams[$emailKey] = $tokenLike;
            $hintParams[$fullNameKey] = $tokenLike;
            $hintParams[$reverseNameKey] = $tokenLike;
            $tokenIndex++;
        }

        if ($program !== '') {
            $hintSql .= " AND s.program_id = :hint_program";
            $hintParams['hint_program'] = $program;
        }
        if ($level !== '') {
            $hintSql .= " AND s.level_year = :hint_level";
            $hintParams['hint_level'] = $level;
        }

        $hintSql .= " ORDER BY s.created_at DESC LIMIT 3";
        $hintStmt = $conn->prepare($hintSql);
        foreach ($hintParams as $k => $v) {
            $hintStmt->bindValue(':' . $k, $v);
        }
        $hintStmt->execute();
        $hintMatches = $hintStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        if (!empty($hintMatches)) {
            $match = $hintMatches[0];
            $searchFilterHint = 'Search found '
                . trim((string)($match['first_name'] ?? '') . ' ' . (string)($match['last_name'] ?? ''))
                . ' (' . resolveDisplayedStudentRegistrationNumberFromRow($conn, $match) . ')'
                . ', but the current status filter "' . $status . '" excludes this record. '
                . 'Current student status is "' . (string)($match['status'] ?? 'n/a') . '"'
                . (!empty($match['academic_status']) ? ' and academic status is "' . (string)$match['academic_status'] . '"' : '')
                . '.';
        }
    } catch (Exception $e) {
        $searchFilterHint = null;
    }
}
$displayStart = $totalStudents > 0 ? ($offset + 1) : 0;
$displayEnd = $totalStudents > 0 ? min($offset + count($students), $totalStudents) : 0;
$clearStatusFilterUrl = $buildListUrl(1, $rowsPerPage, $search, $program, '', $level);

// Get programs for filter
$stmt = $conn->query("SELECT * FROM programs WHERE status = 'active' ORDER BY program_name");
$programs = $stmt->fetchAll();

// Notifications (per-user + broadcast aware)
$currentUser = isset($currentUser) ? $currentUser : $auth->getCurrentUser();
$unreadNotifications = fetchUnreadNotificationsForUser($currentUser['id'], 10);

$pageTitle = 'Students List - ' . APP_NAME;
include '../../../includes/header.php';
?>

<style>
body { overflow-x: hidden; }
.main-content { max-width: 100%; overflow-x: hidden; }
.content-area { overflow-x: hidden; }
.table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; max-width: 100%; }
.students-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap; }
.students-toolbar-right { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.students-meta { color: #64748b; font-size: 12px; font-weight: 600; }
.students-per-page label { margin-bottom: 0; font-size: 12px; font-weight: 600; color: #475569; }
.students-table { width: 100%; table-layout: fixed; }
.students-table th, .students-table td { white-space: normal; word-break: break-word; vertical-align: top; }
.students-table .col-id { width: 120px; }
.students-table .col-name { width: 180px; }
.students-table .col-adm { width: 130px; }
.students-table .col-program { width: 170px; }
.students-table .col-level { width: 72px; }
.students-table .col-status { width: 96px; }
.students-table .col-actions { width: 220px; }
.students-name-wrap, .students-program-wrap { overflow: hidden; text-overflow: ellipsis; }
.form-control-sm,
select.form-control-sm {
    min-height: 38px;
    height: 38px;
    line-height: 1.35;
    padding-top: 0.4rem;
    padding-bottom: 0.4rem;
    color: #1f2937;
    background-color: #fff;
}
select.form-control-sm {
    padding-right: 2rem;
}
select.form-control-sm option {
    color: #1f2937;
    background: #fff;
}
.btn-group .btn { padding: 0.25rem 0.5rem; font-size: 0.82rem; }
.dropdown-menu { min-width: 180px; z-index: 9999; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border: 1px solid #dee2e6; }
.student-actions-inline {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    flex-wrap: wrap;
}
.students-footer { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
.students-pagination .pagination { margin-bottom: 0; }
.students-search-wrap { position: relative; }
.students-search-preview {
    display: none;
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    right: 0;
    z-index: 30;
    background: #fff;
    border: 1px solid #dbe2ea;
    border-radius: 10px;
    box-shadow: 0 10px 25px rgba(15, 23, 42, 0.10);
    overflow: hidden;
}
.students-search-preview.is-visible {
    display: block;
}
.students-search-preview-item {
    display: block;
    width: 100%;
    padding: 10px 12px;
    text-align: left;
    border: 0;
    border-bottom: 1px solid #edf2f7;
    background: transparent;
    cursor: pointer;
}
.students-search-preview-item:last-child {
    border-bottom: 0;
}
.students-search-preview-item:hover,
.students-search-preview-item:focus {
    background: #f8fafc;
    outline: none;
}
.students-search-preview-name {
    display: block;
    font-weight: 600;
    color: #1e293b;
}
.students-search-preview-meta {
    display: block;
    margin-top: 2px;
    color: #64748b;
    font-size: 12px;
}
.students-search-helper {
    margin-top: 8px;
    color: #64748b;
    font-size: 12px;
    font-weight: 600;
}
@media (max-width: 1200px) {
    .students-table { font-size: 0.82rem; }
}
@media (max-width: 768px) {
    .students-table .col-adm,
    .students-table .col-program { width: 110px; }
    .students-table .col-actions { width: 190px; }
}
</style>

<?php include '../../../includes/admin/sidebar.php'; ?>

<div class="main-content">
    <div class="topbar">
        <div class="topbar-left">
            <h4>Students Management</h4>
        </div>
        <div class="topbar-right">
            <div class="topbar-time">
                <div id="current-date-time">
                    <div class="time-display"><?php echo date('h:i:s A'); ?></div>
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                </div>
            </div>
            <?php include '../../../includes/notification_bell.php'; ?>
            <div class="user-dropdown">
                <button class="user-dropdown-toggle" id="userDropdown">
                    <div class="user-avatar-sm">
                        <?php echo strtoupper(substr($currentUser['profile']['first_name'] ?? 'A', 0, 1) . substr($currentUser['profile']['last_name'] ?? 'D', 0, 1)); ?>
                    </div>
                    <i class="dropdown-arrow">▼</i>
                </button>
                <div class="user-dropdown-menu" id="userDropdownMenu">
                    <div class="user-profile-meta">
                        <div class="user-fullname"><?php echo e($currentUser['profile']['first_name'] ?? ''); ?> <?php echo e($currentUser['profile']['last_name'] ?? ''); ?></div>
                        <?php if (!empty($currentUser['profile']['email'])): ?>
                            <div class="user-email"><i class="fas fa-envelope"></i> <?php echo e($currentUser['profile']['email']); ?></div>
                        <?php endif; ?>
                    </div>
                    <a href="../dashboard.php" class="dropdown-item">
                        <i>🏠</i> Dashboard
                    </a>
                    <a href="../profile.php" class="dropdown-item">
                        <i>👤</i> Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo BASE_URL; ?>/views/admin/logout.php" class="dropdown-item logout-item">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="content-area">
        <?php if ($session->getFlash('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $session->getFlash('success'); ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>
        
        <!-- Filters -->
        <div class="card mb-3">
            <div class="card-body">
                <form method="GET" action="" class="form-row">
                    <input type="hidden" name="per_page" value="<?php echo (int)$rowsPerPage; ?>">
                    <div class="col-md-3 mb-2">
                        <div class="students-search-wrap">
                            <input type="text" id="studentsSearchInput" name="search" class="form-control form-control-sm" placeholder="Search students..." value="<?php echo e($search); ?>" autocomplete="off">
                            <div id="studentsSearchPreview" class="students-search-preview" aria-live="polite"></div>
                        </div>
                        <div id="studentsSearchHelper" class="students-search-helper">Type a student name, student ID, or admission number.</div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <select name="program" class="form-control form-control-sm">
                            <option value="">All Programs</option>
                            <?php foreach($programs as $prog): ?>
                                <option value="<?php echo $prog['id']; ?>" <?php echo $program == $prog['id'] ? 'selected' : ''; ?>>
                                    <?php echo e($prog['program_code']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2 mb-2">
                        <select name="status" class="form-control form-control-sm">
                            <option value="">All Status</option>
                            <option value="active" <?php echo $status == 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $status == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="graduated" <?php echo $status == 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                            <option value="suspended" <?php echo $status == 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                        </select>
                    </div>
                    <div class="col-md-2 mb-2">
                        <select name="level" class="form-control form-control-sm">
                            <option value="">All Levels</option>
                            <option value="1" <?php echo $level == '1' ? 'selected' : ''; ?>>Year 1</option>
                            <option value="2" <?php echo $level == '2' ? 'selected' : ''; ?>>Year 2</option>
                            <option value="3" <?php echo $level == '3' ? 'selected' : ''; ?>>Year 3</option>
                            <option value="4" <?php echo $level == '4' ? 'selected' : ''; ?>>Year 4</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-primary btn-sm mr-1">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                        <a href="<?php echo e($buildListUrl(1, $rowsPerPage, '', '', '', '')); ?>" class="btn btn-secondary btn-sm mr-1">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                        <a href="<?php echo BASE_URL; ?>/views/admin/students/add.php" class="btn btn-success btn-sm">
                            <i class="fas fa-plus"></i> Add New
                        </a>
                    </div>
                </form>
                <?php if ($searchFilterHint !== null): ?>
                    <div class="alert alert-warning mt-3 mb-0">
                        <?php echo e($searchFilterHint); ?>
                        <a href="<?php echo e($clearStatusFilterUrl); ?>" class="alert-link ml-2">Clear status filter</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Students Table -->
        <div class="card">
            <div class="card-header">
                <div class="students-toolbar">
                    <span><i class="fas fa-users"></i> Students (<?php echo (int)$totalStudents; ?>)</span>
                    <div class="students-toolbar-right">
                        <span class="students-meta">Showing <?php echo (int)$displayStart; ?>-<?php echo (int)$displayEnd; ?> of <?php echo (int)$totalStudents; ?></span>
                        <form method="GET" class="form-inline students-per-page">
                            <?php if ($search !== ''): ?><input type="hidden" name="search" value="<?php echo e($search); ?>"><?php endif; ?>
                            <?php if ($program !== ''): ?><input type="hidden" name="program" value="<?php echo e($program); ?>"><?php endif; ?>
                            <?php if ($status !== ''): ?><input type="hidden" name="status" value="<?php echo e($status); ?>"><?php endif; ?>
                            <?php if ($level !== ''): ?><input type="hidden" name="level" value="<?php echo e($level); ?>"><?php endif; ?>
                            <label for="studentsPerPage" class="mr-2">Rows</label>
                            <select id="studentsPerPage" name="per_page" class="form-control form-control-sm" onchange="this.form.submit()">
                                <?php foreach ($allowedPageSizes as $size): ?>
                                    <option value="<?php echo (int)$size; ?>" <?php echo $rowsPerPage === (int)$size ? 'selected' : ''; ?>><?php echo (int)$size; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <?php if (count($students) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-sm mb-0 students-table">
                            <thead class="thead-light">
                                <tr>
                                    <th class="col-id">Student ID</th>
                                    <th class="col-name">Name</th>
                                    <th class="col-adm">Admission #</th>
                                    <th class="col-program">Program</th>
                                    <th class="col-level">Level</th>
                                    <th class="col-status">Status</th>
                                    <th class="col-actions text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($students as $student): ?>
                                    <?php $presenterProgress = getStudentPresenterProgressMeta($conn, (int)($student['id'] ?? 0), $student); ?>
                                    <tr>
                                        <td><strong><?php echo e(resolveDisplayedStudentRegistrationNumberFromRow($conn, $student)); ?></strong></td>
                                        <td>
                                            <div class="students-name-wrap" title="<?php echo e($student['first_name'] . ' ' . $student['last_name']); ?>">
                                                <?php echo e($student['first_name'] . ' ' . $student['last_name']); ?>
                                            </div>
                                            <small class="text-muted"><?php echo e($student['gender']); ?></small>
                                        </td>
                                        <td><?php echo e($student['admission_number'] ?? 'N/A'); ?></td>
                                        <td>
                                            <div class="students-program-wrap" title="<?php echo e($student['program_name']); ?>">
                                                <strong><?php echo e($student['program_code']); ?></strong>
                                            </div>
                                            <small class="text-muted d-block"><?php echo e($student['program_name']); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge badge-secondary"><?php echo e((string)($presenterProgress['progress_label'] ?? ('Y' . (int)($student['level_year'] ?? 1)))); ?></span>
                                            <small class="text-muted d-block"><?php echo e((string)($presenterProgress['stage_label'] ?? 'In Progress')); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php echo Helper::getStatusColor($student['status']); ?>">
                                                <?php echo e(ucfirst($student['status'])); ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group btn-group-sm" role="group">
                                                <a href="view.php?id=<?php echo $student['id']; ?>" class="btn btn-info" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="edit.php?id=<?php echo $student['id']; ?>" class="btn btn-warning" title="Edit Student">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="audit.php?id=<?php echo $student['id']; ?>" class="btn btn-dark" title="Profile Audit">
                                                    <i class="fas fa-history"></i>
                                                </a>
                                                <div class="student-actions-inline">
                                                    <a href="reset_password.php?id=<?php echo $student['id']; ?>" class="btn btn-secondary" title="Reset Password">
                                                        <i class="fas fa-key"></i>
                                                    </a>
                                                    <a href="send_invite.php?id=<?php echo $student['id']; ?>" class="btn btn-primary" title="Send Invite">
                                                        <i class="fas fa-envelope"></i>
                                                    </a>
                                                    <a href="graduation-awards.php?id=<?php echo $student['id']; ?>" class="btn btn-success" title="Graduation & Awards">
                                                        <i class="fas fa-certificate"></i>
                                                    </a>
                                                    <a href="delete.php?id=<?php echo $student['id']; ?>&return_to=<?php echo urlencode($currentListUrl); ?>" class="btn btn-danger" title="Delete Student" onclick="return confirm('Are you sure you want to delete this student?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="students-footer p-3 border-top">
                        <div class="students-meta">Showing <?php echo (int)$displayStart; ?>-<?php echo (int)$displayEnd; ?> of <?php echo (int)$totalStudents; ?> students</div>
                        <div class="students-pagination">
                            <ul class="pagination pagination-sm">
                                <li class="page-item <?php echo $currentPage <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="<?php echo e($buildListUrl(max(1, $currentPage - 1), $rowsPerPage, $search, $program, $status, $level)); ?>">Previous</a>
                                </li>
                                <?php
                                    $startPage = max(1, $currentPage - 2);
                                    $endPage = min($totalPages, $currentPage + 2);
                                    for ($p = $startPage; $p <= $endPage; $p++):
                                ?>
                                    <li class="page-item <?php echo $p === $currentPage ? 'active' : ''; ?>">
                                        <a class="page-link" href="<?php echo e($buildListUrl($p, $rowsPerPage, $search, $program, $status, $level)); ?>"><?php echo (int)$p; ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo $currentPage >= $totalPages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="<?php echo e($buildListUrl(min($totalPages, $currentPage + 1), $rowsPerPage, $search, $program, $status, $level)); ?>">Next</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-users fa-3x text-muted mb-3"></i>
                        <p class="text-muted mb-0">No students found matching your criteria</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var searchInput = document.getElementById('studentsSearchInput');
    var previewBox = document.getElementById('studentsSearchPreview');
    var helperBox = document.getElementById('studentsSearchHelper');
    var form = searchInput ? searchInput.form : null;
    if (!searchInput || !previewBox || !form) {
        return;
    }

    var debounceTimer = null;
    var activeController = null;
    var activeRequest = 0;

    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            }[char] || char;
        });
    }

    function hidePreview() {
        previewBox.classList.remove('is-visible');
        previewBox.innerHTML = '';
    }

    function setHelper(message) {
        if (helperBox) {
            helperBox.textContent = message || 'Type a student name, student ID, or admission number.';
        }
    }

    function renderMatches(matches) {
        if (!Array.isArray(matches) || matches.length === 0) {
            hidePreview();
            setHelper('No matching student names found for the current filters.');
            return;
        }

        previewBox.innerHTML = matches.map(function (match) {
            var name = escapeHtml(match.name || '');
            var studentId = escapeHtml(match.student_id || '');
            var admission = escapeHtml(match.admission_number || '');
            var meta = admission ? (studentId + ' | ' + admission) : studentId;
            return '<button type="button" class="students-search-preview-item" data-value="' + name + '">' +
                '<span class="students-search-preview-name">' + name + '</span>' +
                '<span class="students-search-preview-meta">' + meta + '</span>' +
            '</button>';
        }).join('');
        previewBox.classList.add('is-visible');
        setHelper(matches.length === 1 ? '1 matching student found.' : (matches.length + ' matching students found.'));
    }

    function fetchMatches() {
        var value = (searchInput.value || '').trim();
        if (value.length < 2) {
            hidePreview();
            setHelper('Type a student name, student ID, or admission number.');
            return;
        }

        activeRequest += 1;
        var requestId = activeRequest;
        if (activeController) {
            activeController.abort();
        }
        activeController = typeof AbortController !== 'undefined' ? new AbortController() : null;

        var url = new URL(window.location.href);
        url.searchParams.set('student_lookup', '1');
        url.searchParams.set('term', value);
        url.searchParams.delete('page');

        fetch(url.toString(), {
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            signal: activeController ? activeController.signal : undefined
        })
        .then(function (response) { return response.json(); })
        .then(function (payload) {
            if (requestId !== activeRequest) {
                return;
            }
            renderMatches(payload && payload.matches ? payload.matches : []);
        })
        .catch(function (error) {
            if (error && error.name === 'AbortError') {
                return;
            }
            hidePreview();
            setHelper('Unable to load student suggestions right now.');
        });
    }

    searchInput.addEventListener('input', function () {
        if (debounceTimer) {
            clearTimeout(debounceTimer);
        }
        debounceTimer = setTimeout(fetchMatches, 220);
    });

    searchInput.addEventListener('focus', function () {
        if ((searchInput.value || '').trim().length >= 2) {
            fetchMatches();
        }
    });

    previewBox.addEventListener('click', function (event) {
        var button = event.target.closest('.students-search-preview-item');
        if (!button) {
            return;
        }
        searchInput.value = button.getAttribute('data-value') || '';
        hidePreview();
        form.submit();
    });

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.students-search-wrap')) {
            hidePreview();
        }
    });
});
</script>

<?php include '../../../includes/footer.php'; ?>
